﻿using System.ComponentModel.DataAnnotations;
namespace WebApplication7.Models
{
    public class Payment
    {
     
        public string CardHolderName{get; set;}
        
        [Key]
        public long CardNumber{ get; set; }
        public string ExpiryDate { get; set; }
        public int CVV { get; set; }

    }
}
