﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using WebApplication7.Models;

namespace WebApplication7.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public PaymentController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpGet]
        public JsonResult Get()
        {
            string query = @"select * from tbl_payment";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("Payment");
            SqlDataReader myReader;
            using (SqlConnection mycon = new SqlConnection(sqlDataSource))
            {
                mycon.Open();
                using (SqlCommand myCommand = new SqlCommand(query,mycon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult(table);
        
        }
        [HttpPost]
        public JsonResult Post(Payment pay)
        {
            string query = @"
                    insert into tbl_payment(CardHolderName,CardNumber,ExpiryDate,CVV)values('"  + pay.CardHolderName + @"','" + pay.CardNumber + @"','" + pay.ExpiryDate + @"','" + pay.CVV + @"')";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("Payment");
            SqlDataReader myReader;
            using (SqlConnection mycon = new SqlConnection(sqlDataSource))
            {
                mycon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, mycon))
                {

                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult("Added Successfully");

            }
        [HttpPut]
        public JsonResult Put(Payment pay)
        {
            string query = @"
                    update tbl_payment set
                   
                     CardHolderName = '" + pay.CardHolderName + @"'
                    ,CardNumber = '" + pay.CardNumber + @"'
                    ,ExpiryDate = '" + pay.ExpiryDate + @"'
                    ,CVV = '" + pay.CVV + @"'
                    where CardHolderName = " + pay.CardHolderName + @"
                    ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("Payment");
            SqlDataReader myReader;
            using (SqlConnection mycon = new SqlConnection(sqlDataSource))
            {
                mycon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, mycon))
                {

                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult("Updated Successfully");

        }

        [HttpDelete("{CardHolderName}")]
        public JsonResult Delete(string CardHolderName)
        {
            string query = @"delete from tbl_Payment where CardHolderName = " + CardHolderName+ @"";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("Payment");
            SqlDataReader myReader;
            using (SqlConnection mycon = new SqlConnection(sqlDataSource))
            {
                mycon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, mycon))
                {


                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult("Deleted");

        }
    }
}
